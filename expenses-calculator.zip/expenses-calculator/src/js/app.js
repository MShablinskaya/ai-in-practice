document.addEventListener('DOMContentLoaded', () => {
    const addCategoryForm = document.getElementById('add-category-form');
    const categoryTableBody = document.querySelector('#category-table tbody');

    function recalculateTotals() {
        const amountInputs = document.querySelectorAll('.category-amount');
        let amounts = [];
        let total = 0;

        amountInputs.forEach(input => {
            const val = parseFloat(input.value);
            if (!isNaN(val) && val > 0) {
                amounts.push({ 
                    category: input.dataset.category || 'Unknown', 
                    amount: val 
                });
                total += val;
            }
        });

        document.getElementById('total-expenses').textContent = total.toFixed(2);
        document.getElementById('average-daily-expense').textContent = (total / 30).toFixed(2);

        const topThree = amounts.sort((a, b) => b.amount - a.amount).slice(0, 3);
        const topThreeList = document.getElementById('top-three-expenses');
        topThreeList.innerHTML = '';
        if (topThree.length === 0) {
            topThreeList.innerHTML = '<li>None</li>';
        } else {
            topThree.forEach(item => {
                const li = document.createElement('li');
                li.textContent = `${item.category}: $${item.amount.toFixed(2)}`;
                topThreeList.appendChild(li);
            });
        }
    }

    addCategoryForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const newCategoryInput = document.getElementById('new-category-name');
        const newAmountInput = document.getElementById('new-category-amount');
        const newCategory = newCategoryInput.value.trim();
        const newAmount = parseFloat(newAmountInput.value);
        if (newCategory && !isNaN(newAmount)) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${newCategory}</td>
                <td><input type="number" min="0" step="0.01" class="category-amount" data-category="${newCategory}" value="${newAmount}"></td>
            `;
            categoryTableBody.appendChild(row);
            newCategoryInput.value = '';
            newAmountInput.value = '';
            recalculateTotals();
        }
    });

    document.getElementById('calculate-btn').addEventListener('click', recalculateTotals);
});